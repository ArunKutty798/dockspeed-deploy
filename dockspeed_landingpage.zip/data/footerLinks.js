export const exploreLinks = [
  { name: "Showroom", link: "/" },
  { name: "Garage", link: "/garage" },
  { name: "Contact us", link: "/contact_us" },
];

export const legalLinks = [
  { name: "Privacy policy", link: "/privacy_policy" },
  { name: "Terms of use", link: "/terms_of_use" },
  { name: "Copyrights", link: "/copyrights" },
];
