export const newelyMintedEquipments = [
  {
    image: "/equipment1.png",
    heading: "1500CC Spencer Engine",
    about:
      "This is a piece of art Spencer’ Engine, manufactured in 2018, 858 BHP and 603 NM torque converter engine. Token Id: #4545DF2",
    tokenId: "#4545DF2",
    dateTime: "28 Aug 2021, 05:14 AM",
    auction: "true",
    carsAvailable: "21 of 100",
    reserverdPrice: "79.68 ETH",
  },
  {
    image: "/equipment2.png",
    heading: "Nissan GTR Sport",
    about:
      "This is a piece of art Spencer’ Engine, manufactured in 2018, 858 BHP and 603 NM torque converter engine. Token Id: #4545DF2",
    tokenId: "#4545DF2",
    dateTime: "28 Aug 2021, 05:14 AM",
    auction: "true",
    carsAvailable: "21 of 100",
    reserverdPrice: "79.68 ETH",
  },
  {
    image: "/equipment3.png",
    heading: "BMW M8 Coupe",
    about:
      "This is a piece of art Spencer’ Engine, manufactured in 2018, 858 BHP and 603 NM torque converter engine. Token Id: #4545DF2",
    tokenId: "#4545DF2",
    dateTime: "28 Aug 2021, 05:14 AM",
    auction: "true",
    carsAvailable: "21 of 100",
    reserverdPrice: "79.68 ETH",
  },
  {
    image: "/equipment4.png",
    heading: "Bugatti Veyron",
    about:
      "This is a piece of art Spencer’ Engine, manufactured in 2018, 858 BHP and 603 NM torque converter engine. Token Id: #4545DF2",
    tokenId: "#4545DF2",
    dateTime: "28 Aug 2021, 05:14 AM",
    auction: "true",
    carsAvailable: "21 of 100",
    reserverdPrice: "79.68 ETH",
  },
  {
    image: "/equipment5.png",
    heading: "Koenigsegg Cameron",
    about:
      "This is a piece of art Spencer’ Engine, manufactured in 2018, 858 BHP and 603 NM torque converter engine. Token Id: #4545DF2",
    tokenId: "#4545DF2",
    dateTime: "28 Aug 2021, 05:14 AM",
    auction: "true",
    carsAvailable: "21 of 100",
    reserverdPrice: "79.68 ETH",
  },
  {
    image: "/equipment6.png",
    heading: "Lexus LF Sport Hybrid",
    about:
      "This is a piece of art Spencer’ Engine, manufactured in 2018, 858 BHP and 603 NM torque converter engine. Token Id: #4545DF2",
    tokenId: "#4545DF2",
    dateTime: "28 Aug 2021, 05:14 AM",
    auction: "true",
    carsAvailable: "21 of 100",
    reserverdPrice: "79.68 ETH",
  },
];
