const dataSlider = [
  {
    id: 1,
    title: "Lorem ipsum",
    subTitle: "Lorem",
    image: "/cars/car1.png",
  },
  {
    id: 2,
    title: "Lorem ipsum",
    subTitle: "Lorem",
    image: "/cars/car2.png",
  },
  {
    id: 3,
    title: "Lorem ipsum",
    subTitle: "Lorem",
    image: "/cars/car3.png",
  },
  {
    id: 4,
    title: "Lorem ipsum",
    subTitle: "Lorem",
    image: "/cars/car4.png",
  },
  {
    id: 5,
    title: "Lorem ipsum",
    subTitle: "Lorem",
    image: "/cars/car5.png",
  },
];

export default dataSlider;
