export const newelyMintedCars = [
  {
    image: "/car.png",
    heading: "Porsche 911 Carerra GT Sport",
    about:
      "This is a piece of art Porsche 911 Carerra GT Sport, manufactured in 2018, 858 BHP and 603 NM torque converter engine. Token Id:",
    tokenId: "#4545DF2",
    dateTime: "28 Aug 2021, 05:14 AM",
    auction: "true",
    carsAvailable: "21 of 100",
    reserverdPrice: "79.68 ETH",
  },
  {
    image: "/car2.png",
    heading: "Nissan GTR Sport",
    about:
      "This is a piece of art Porsche 911 Carerra GT Sport, manufactured in 2018, 858 BHP and 603 NM torque converter engine. Token Id:",
    tokenId: "#4545DF2",
    dateTime: "28 Aug 2021, 05:14 AM",
    auction: "true",
    carsAvailable: "21 of 100",
    reserverdPrice: "79.68 ETH",
  },
  {
    image: "/car3.png",
    heading: "BMW M8 Coupe",
    about:
      "This is a piece of art Porsche 911 Carerra GT Sport, manufactured in 2018, 858 BHP and 603 NM torque converter engine. Token Id:",
    tokenId: "#4545DF2",
    dateTime: "28 Aug 2021, 05:14 AM",
    auction: "true",
    carsAvailable: "21 of 100",
    reserverdPrice: "79.68 ETH",
  },
  {
    image: "/car4.png",
    heading: "Bugatti Veyron",
    about:
      "This is a piece of art Porsche 911 Carerra GT Sport, manufactured in 2018, 858 BHP and 603 NM torque converter engine. Token Id:",
    tokenId: "#4545DF2",
    dateTime: "28 Aug 2021, 05:14 AM",
    auction: "true",
    carsAvailable: "21 of 100",
    reserverdPrice: "79.68 ETH",
  },
  {
    image: "/car5.png",
    heading: "Koenigsegg Cameron",
    about:
      "This is a piece of art Porsche 911 Carerra GT Sport, manufactured in 2018, 858 BHP and 603 NM torque converter engine. Token Id:",
    tokenId: "#4545DF2",
    dateTime: "28 Aug 2021, 05:14 AM",
    auction: "true",
    carsAvailable: "21 of 100",
    reserverdPrice: "79.68 ETH",
  },
  {
    image: "/car6.png",
    heading: "Lexus LF Sport Hybrid",
    about:
      "This is a piece of art Porsche 911 Carerra GT Sport, manufactured in 2018, 858 BHP and 603 NM torque converter engine. Token Id:",
    tokenId: "#4545DF2",
    dateTime: "28 Aug 2021, 05:14 AM",
    auction: "true",
    carsAvailable: "21 of 100",
    reserverdPrice: "79.68 ETH",
  }
];
