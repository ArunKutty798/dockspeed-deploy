export const nftMarketplace = [
  {
    image: "/icons/showroom.svg",
    heading: "Showroom",
    about:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Turpis semper etiam tincidunt varius sodales aenean fringilla. Mauris est vitae vitae.",
  },
  {
    image: "/icons/token.svg",
    heading: "RAC Token",
    about:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Turpis semper etiam tincidunt varius sodales aenean fringilla. Mauris est vitae vitae.",
  },
  {
    image: "/icons/dividend.svg",
    heading: "Dividend",
    about:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Turpis semper etiam tincidunt varius sodales aenean fringilla. Mauris est vitae vitae.",
  },
  {
    image: "/icons/autoParts.svg",
    heading: "Auto parts",
    about:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Turpis semper etiam tincidunt varius sodales aenean fringilla. Mauris est vitae vitae.",
  },
  {
    image: "/icons/flashSale.svg",
    heading: "Flash Sale",
    about:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Turpis semper etiam tincidunt varius sodales aenean fringilla. Mauris est vitae vitae.",
  },
  {
    image: "/icons/racingPools.svg",
    heading: "Racing Pools",
    about:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Turpis semper etiam tincidunt varius sodales aenean fringilla. Mauris est vitae vitae.",
  },
  {
    image: "/icons/createPools.svg",
    heading: "Creating Race Pools",
    about:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Turpis semper etiam tincidunt varius sodales aenean fringilla. Mauris est vitae vitae.",
  },
  {
    image: "/icons/requestOwnership.svg",
    heading: "Request Ownership",
    about:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Turpis semper etiam tincidunt varius sodales aenean fringilla. Mauris est vitae vitae.",
  },
];
