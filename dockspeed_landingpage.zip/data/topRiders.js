export const topRiders = [
  {
    image: "/rider1.png",
    rank: "01",
    name: "Kathryn Murphy",
    team: "Paris Pool",
    marginLeft: "0%"
  },
  {
    image: "/rider2.png",
    rank: "02",
    name: "Albert Flores",
    team: "Amsterdam Pool",
  },
  {
    image: "/rider3.png",
    rank: "03",
    name: "Ralph Edwards",
    team: "Mumbai Pool",
  },
  {
    image: "/rider2.png",
    rank: "04",
    name: "Jenny Wilson",
    team: "London Pool",
  },
  {
    image: "/rider1.png",
    rank: "04",
    name: "Jenny Wilson",
    team: "London Pool",
  },
];

